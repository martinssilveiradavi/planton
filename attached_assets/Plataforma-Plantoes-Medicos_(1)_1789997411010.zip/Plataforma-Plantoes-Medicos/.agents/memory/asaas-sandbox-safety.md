---
name: Asaas sandbox safety
description: Safe environment detection and test-document handling for Asaas payment validation.
---

Treat any Asaas base URL containing `sandbox` as a test environment because both legacy and current hostname formats exist. In non-production runtime, reject Asaas endpoints that are neither sandbox nor a loopback test server.

**Why:** Exact-hostname detection misclassified a configured Asaas endpoint, causing repeated CPF/CNPJ validation failures and risking calls to the wrong environment during payment validation.

**How to apply:** Keep sandbox customer fixtures isolated from production behavior. Allow loopback hosts only for automated tests, and require the actual Asaas Sandbox URL and key before performing an end-to-end payment test.