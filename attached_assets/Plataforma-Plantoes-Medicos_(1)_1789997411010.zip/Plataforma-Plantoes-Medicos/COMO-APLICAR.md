# Aplicar no projeto original da equipe

Este pacote corresponde ao ZIP enviado. Não foi enviado ao Replit nem publicado.

Antes de aplicar, compare com o estado atual: o Agent da equipe pode ter alterado outros arquivos desde a exportação. Não substitua o projeto inteiro nem importe como novo aplicativo.

Arquivos alterados:
- artifacts/planton-app/index.html — idioma, title e descrições.
- artifacts/planton-app/src/pages/discovery.tsx — cabeçalho com H1.
- artifacts/planton-app/src/App.tsx — captura de navegação.
- artifacts/planton-app/public/robots.txt — regras e referência ao sitemap.

Arquivos novos:
- artifacts/planton-app/public/sitemap.xml
- artifacts/planton-app/public/llms.txt
- artifacts/planton-app/src/lib/analytics.ts
- artifacts/planton-app/.env.posthog.example
- ENTREGA-PLANTON.md
- COMO-APLICAR.md

Use o arquivo alteracoes.patch para revisar e aplicar apenas estas mudanças à versão compatível do código, ou peça ao Agent para integrar o patch preservando alterações posteriores. Se houver conflito, não force a aplicação.

Não há novas dependências: o PostHog carrega seu SDK oficial de forma assíncrona. Se o carregamento falhar, isso não bloqueia a interface. Configure o token e o host, execute o build habitual e publique com um usuário autorizado. Confira os três links e o painel PostHog antes da entrega no Canvas.

O pacote exclui histórico Git, dependências, caches e arquivos .env com configurações locais. Preserve os Secrets já cadastrados no Replit.
